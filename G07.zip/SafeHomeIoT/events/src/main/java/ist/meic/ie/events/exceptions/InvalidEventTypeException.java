package ist.meic.ie.events.exceptions;

public class InvalidEventTypeException extends Exception{

    public InvalidEventTypeException() {
        super();
    }

    public InvalidEventTypeException(String msg) {
        super(msg);
    }
}
